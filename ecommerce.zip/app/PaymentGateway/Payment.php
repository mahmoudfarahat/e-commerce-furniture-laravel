<?php


namespace App\PaymentGateway;


class Payment{

    public static function process()
    {
        echo 'prorcessing the payment';
    }
}

