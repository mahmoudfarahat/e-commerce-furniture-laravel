<?php $__env->startSection('title', 'Show Products'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row mt-4">
            <div class="col-7 ">
                <img src="<?php echo e(asset('uploads/products/' . $product->prodpicture)); ?>"  alt="">

            </div>

            <div class="col-5">
                <h2 class="card-title mt-5"><?php echo e($product->prodname); ?></h2>
                <h4 class="card-text"><?php echo e($product->prodprice); ?>$</h4>

                <form action="<?php echo e(url('/addtocart/' . $product->id)); ?>" method="POST" class="mt-5">
                    <?php echo csrf_field(); ?>

                    <input type="number" class="form-control mb-3" placeholder="Quantity" name="quantity">
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="submit" class="btn btn-dark d-block mb-3 form-control">Add To Cart</button>

                </form>

                <a href="" class="btn btn-outline-dark d-block">Buy</a>
            </div>


        </div>




    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/product/single-product.blade.php ENDPATH**/ ?>