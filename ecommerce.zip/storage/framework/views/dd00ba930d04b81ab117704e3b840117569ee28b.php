<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page Not Found</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>


    <section style="padding-top:100px">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 text-center">
            <h1 style="font-size: 162px"> 404</h1>
            <h2>Page Not Found</h2>
            <p>We are sorry, the page you requested could not be found </p>
            <a href="<?php echo e(url('/product')); ?>" class="btn btn-primary">Visit Homepage</a>

            </div></div></div></section>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\learingNow\resources\views/errors/404.blade.php ENDPATH**/ ?>