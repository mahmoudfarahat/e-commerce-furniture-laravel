<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">

    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">

            <img src="<?php echo e(asset('uploads/1.jpg')); ?>"  class="d-block w-100"  alt="">
            <div class="carousel-caption d-none d-md-block">
              <a href="<?php echo e(url('product')); ?>" class="btn btn-dark btn-lg">Shop</a>

            </div>
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('uploads/2.jpg')); ?>"  class="d-block w-100"  alt="">
            <div class="carousel-caption d-none d-md-block">
                <a href="<?php echo e(url('product')); ?>" class="btn btn-dark btn-lg">Shop</a>

            </div>
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('uploads/3.jpg')); ?>"  class="d-block w-100"  alt="">
            <div class="carousel-caption d-none d-md-block">
                <a href="<?php echo e(url('product')); ?>" class="btn btn-dark btn-lg">Shop</a>

            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
</div>

<div class="container mt-5" id="story">
    <div class="card bg-dark text-white">
        <img src="<?php echo e(asset('uploads/5.jpg')); ?>" class="card-img" alt="...">
        <div class="card-img-overlay">
          <h2 class="card-title text-center display-1 position-absolute top-50 start-50 translate-middle fw-bold">Our Story</h2>

        </div>
      </div>

      <h4 class="text-center mt-5"> a place where all kinds of good things come together.</h4>

      <div class="row mt-5">
        <div class="col-6">
            <img src="<?php echo e(asset('uploads/6.jpg')); ?>" class="card-img" alt="...">
        </div>
        <div class="col-6 d-flex align-items-center  ">
<div  >
    <h5>A happy place</h5>
     a place where all kinds of good things come together. It's a collage of whimsy and restraint, an ode to vintage and a nod to experimentation, a mixture of the familiar with the exotic.</div>

        </div>
</div>

<div class="row mt-4">

    <div class="col-6 d-flex align-items-center  ">
<div  >
<h5>A happy place</h5>
 a place where all kinds of good things come together. It's a collage of whimsy and restraint, an ode to vintage and a nod to experimentation, a mixture of the familiar with the exotic.</div>

    </div>
    <div class="col-6">
        <img src="<?php echo e(asset('uploads/7.jpg')); ?>" class="card-img" alt="...">
    </div>
</div>
      </div>
</div>
<div class="container mt-5" id="contact">
    <div class="card mb-3 "  style="max-width: 1500px;">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="<?php echo e(asset('uploads/4.jpg')); ?>" class="img-fluid rounded-start" alt="...">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">Subscribe to our newsletter</h5>
              <p class="card-text">Promotions, new products and sales. Directly to your inbox.</p>
              <form action="<?php echo e(url('sendContact')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                <input type="text" name="name" class="form-control   <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " placeholder="Name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?> </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
            <div class="mb-3">
                <input type="text" name="phone" class="form-control   <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " placeholder="Phone">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?> </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
<div class="mb-3">
    <input type="text" name="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " placeholder="E-mail">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="text-danger"><?php echo e($message); ?> </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

                <button class="btn btn-dark form-control">Submit</button>


              </form>
            </div>
          </div>
        </div>
      </div>

</div>



 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/index.blade.php ENDPATH**/ ?>