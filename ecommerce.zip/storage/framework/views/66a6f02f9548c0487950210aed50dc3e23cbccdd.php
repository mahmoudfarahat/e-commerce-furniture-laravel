<?php $__env->startSection('title', 'Make an Order'); ?>
<?php $__env->startSection('content'); ?>







    <div class="container">
        <h2>My Orders</h2>
        <br>

        <div class="row mb-3">

            <div class="col-6">
                <div class="card ">
                    <div class="card-body d-flex justify-content-between">
                        <h5 class="card-title">On Delivery</h5>
                        <h5> <?php echo e($onDeliveryOrderCount); ?></h5>

                    </div>
                </div>

            </div>
            <div class="col-6">
                <div class="card">
                    <div class="card-body d-flex justify-content-between ">
                        <h5 class="card-title">Finished </h5>
                        <h6 class="card-subtitle mb-2 text-muted"> </h6>

                    </div>
                </div>

            </div>
        </div>


        <hr>


        <table class="table text-center">
            <thead>
                <tr>
                    <th scope="col">Order ID</th>
                    <th scope="col">Total Price</th>
                    <th scope="col">Data Order</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>

            </thead>
            <tbody>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($orderw->id); ?></th>
                        <td></td>
                        <td><?php echo e($orderw->created_at); ?></td>
                        <td><?php echo e($orderw->quantities); ?></td>





                        <td class="bg-danger "><?php echo e($orderw->finished); ?></td>
                        <td class="  ">
                            <a href="" class="btn btn-primary">Open</a>
                           
                            <a  href=""  class="  btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal_<?php echo e($orderw->id); ?>">Delete</a>
                        </td>



                    </tr>

                    <div class="modal fade" id="exampleModal_<?php echo e($orderw->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Delete your order?</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>

                                <form action="<?php echo e(url('/'.$orderw->id )); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="put">


                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>









                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>














<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/order/myorders.blade.php ENDPATH**/ ?>