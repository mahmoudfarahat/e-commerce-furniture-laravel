<?php $__env->startSection('title','Import Data'); ?>

<?php $__env->startSection('content'); ?>







<h5>hi</h5>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/customers/profile.blade.php ENDPATH**/ ?>