<?php $__env->startSection('title', 'order'); ?>
<?php $__env->startSection('content'); ?>




<div class="container">
    <h2>Order Information:</h2>
    <h5>Quantity:</h5>
    <h5>Total Price:</h5>
    <h4></h4>


    <hr>
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-3">
                    <div class="card">

                        <img src="<?php echo e(asset('uploads/products/' . $product->prodpicture)); ?>" class="card-img-top" alt="">

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->prodname); ?></h5>
                            <div class="d-flex justify-content-between">
                                <p class="card-text"><?php echo e($product->prodprice); ?>$</p>


                            </div>



                        </div>

                    </div>
                </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/customers/singleorder.blade.php ENDPATH**/ ?>