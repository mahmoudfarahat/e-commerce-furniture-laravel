<?php $__env->startSection('title', 'Show Products'); ?>
<?php $__env->startSection('content'); ?>

    






    <div class="container">




        <div class="row my-5">
            <?php if(Session::has('product_added')): ?>
                <div class="alert-success alert" role="alert">
                    <?php echo e(Session::get('product_added')); ?>

                </div>
            <?php endif; ?>




            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($product->quantity == 0): ?>

                    <?php
                        $d_btn_cart_buy = 'd-none';
                        $d_bought = '';
                    ?>
                <?php else: ?>
                    <?php
                        $d_btn_cart_buy = '';
                        $d_bought = 'd-none';
                    ?>
                <?php endif; ?>



                <div class="col-3">
                    <div class="card border-0">
                     <a href="<?php echo e(url('/product/'. $product->id  )); ?>"><img src="<?php echo e(asset('uploads/products/' . $product->prodpicture)); ?>" class="card-img-top" alt=""></a>

                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->prodname); ?></h5>
                            <p class="card-text"><?php echo e($product->prodprice); ?>$</p>

                            <div class="<?php echo e($d_btn_cart_buy); ?>">
                                <a class="btn btn-primary  " data-bs-toggle="modal" data-bs-target="#exampleModal_<?php echo e($product->id); ?>">Add to
                                    Cart</a>
                                <a href="<?php echo e(url('/order/' . $product->id)); ?>" class="btn btn-success "  >Buy</a>
                            </div>
                            <div class="<?php echo e($d_bought); ?> ">
                                <a class="btn btn-danger disabled d-block">Out of Stock</a>
                            </div>
                        </div>

                    </div>

                </div>



                <div class="modal fade" id="exampleModal_<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add the product to you cart</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <form action="<?php echo e(url('/addtocart/' . $product->id )); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="modal-body">
                                    <label class="mb-2">Quantity:</label>
                                    <input class="form-control" name="quantity" type="number">

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Add</button>
                            </form>
                        </div>
                    </div>
                </div>
        </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php echo e($products->links()); ?>


    </div>




    <!-- Modal -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/product/products.blade.php ENDPATH**/ ?>