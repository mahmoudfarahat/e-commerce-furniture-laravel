<?php $__env->startSection('title','Cart'); ?>

<?php $__env->startSection('content'); ?>



  <div class="container">

    <h1 href="">Shopping cart</h1>

    <div class="row">


        <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <th scope="row">
                    <div class="d-flex">
                        <div class="col-md-2    ">
                            <img src="<?php echo e(asset('uploads/products/'.$product->prodpicture)); ?>"  class="card-img-top"    alt="">

                        </div>
                        <div class="ms-4">
                            <a  href="<?php echo e(url('')); ?>" class="  mb-4 d-block "><?php echo e($product->prodname); ?></a>
                            <form action="<?php echo e(url('/cart/'.$product->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <button  class="text-danger btn">Remove</button>
                                <a  class="text-danger btn" data-bs-toggle="modal" data-bs-target="#exampleModal_<?php echo e($product->id); ?>" >Edit qauntity</a>


                            </form>


                        </div>

                    </div>

                </th>
                <td>
                    <p class="card-text mb-0">$<?php echo e($product->prodprice); ?>  </p>

                </td>
                <td>
                    <p class="card-text mb-0"> <?php echo e($product->c_quantity); ?>  </p>


                </td>
                <td>
                    <p class="card-text mb-0"> $<?php echo e($product->total); ?> </p>



                </td>
              </tr>

              <div class="modal fade" id="exampleModal_<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add the product to you cart</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <form action="<?php echo e(url('/cart/' . $product->id )); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="put">
<?php echo e($product->id); ?>

                            <div class="modal-body">
                                <label class="mb-2">Quantity:</label>
                                <input class="form-control" name="quantity" type="number">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </div>
                </div>
            </div>



              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

        <div class="d-flex justify-content-between mb-3">
            <h2>     Subtotal</h2>
<h2> $<?php echo e($total); ?> </h2>
        </div>

        <a href="<?php echo e(url('orderCart')); ?>" class="btn btn-dark">Check Out</a>
    

    </div>


</div>













<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/cart/cart.blade.php ENDPATH**/ ?>