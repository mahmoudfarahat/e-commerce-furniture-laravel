<?php $__env->startSection('title','Make an Order'); ?>
<?php $__env->startSection('content'); ?>






<div class="container">

    <?php if(Session::has('reject')): ?>
    <div class="alert-danger alert" role="alert">
        <?php echo e(Session::get('reject')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::has('order_added')): ?>
    <div class="alert-success alert" role="alert">
        <?php echo e(Session::get('order_added')); ?>

    </div>
    <?php endif; ?>

  <div class="row">
    <div class="col-6">
      <form action="<?php echo e(url('/makeorder/'.request('id'))); ?>" method="POST" class="border p-3 mt-3">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label   class="form-label">Quantity</label>
          <input type="number" name="quantities" value="<?php echo e(old('quantities')); ?>" class="form-control <?php $__errorArgs = ['quantities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " id="exampleInputEmail1" aria-describedby="emailHelp">
          <?php $__errorArgs = ['quantities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="text-danger"><?php echo e($message); ?> </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

         <input type="hidden" name="product_id" value="<?php echo e(request('id')); ?>">
          <div class="mb-3">
            <label   class="form-label">Phone</label>
            <input type="email" value="<?php echo e(old('phone')); ?>"   name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="exampleInputEmail1" aria-describedby="emailHelp">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?> </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
          <div class="mb-3">
            <label   class="form-label">Country</label>
            <input type="text" value="<?php echo e(old('country')); ?>"   name="country" class="form-control <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " id="exampleInputPassword1">
            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?> </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
          <div class="mb-3">
              <label   class="form-label">City</label>
              <input type="text" value="<?php echo e(old('city')); ?>"  name="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " id="exampleInputPassword1">
              <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger"><?php echo e($message); ?> </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          <div class="mb-3">
              <label   class="form-label">Street</label>
              <input type="text"  value="<?php echo e(old('street')); ?>"  name="street"  class="form-control <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  " id="exampleInputPassword1">
              <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger"><?php echo e($message); ?> </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

          <button type="submit" class="btn btn-primary">Make The Order</button>
        </form>
    </div>
    <div class="col-6">
        <div class="  mt-3">
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(asset('uploads/products/'.$product->prodpicture)); ?>"  class="card-img-top"    alt="">

            <div class="card-body">
              <h5 class="card-title"><?php echo e($product->prodname); ?></h5>
              <p class="card-text"><?php echo e($product->prodprice); ?>$</p>

                  <a href="#" class="btn btn-primary">Go somewhere</a>
                </div>
              </div>

        </div>

    </div>
  </div>

</div>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/order/singleOrder.blade.php ENDPATH**/ ?>