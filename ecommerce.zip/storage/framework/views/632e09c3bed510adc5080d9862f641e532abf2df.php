<?php $__env->startSection('title','Make an Order'); ?>
<?php $__env->startSection('content'); ?>






<div class="container">


    <a href="" class="btn btn-danger">Delete The Order</a>
    <a href="" class="btn btn-success" >Deliver The Order</a>


<table class="table">
  <thead>
    <tr>
      <th scope="col"> <h4>Customer Information:</h4></th>
      <th scope="col"> </th>

    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Name</th>
      <td><?php echo e($customer->name); ?></td>

    </tr>
    <tr>
        <th scope="row">Phone</th>
        <td><?php echo e($order->phone); ?></td>

      </tr>
    <tr>
      <th scope="row">Country</th>
      <td><?php echo e($order->country); ?></td>

    </tr>
    <tr>
        <th scope="row">City</th>
        <td><?php echo e($order->city); ?></td>

      </tr>
    <tr>
      <th scope="row">Street</th>
      <td><?php echo e($order->street); ?></td>

    </tr>
  </tbody>
</table>




    <h2>Order Information:</h2>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3">
                <div class="card"  >

                <img src="<?php echo e(asset('uploads/products/'.$product->prodpicture)); ?>"  class="card-img-top"    alt="">

                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($product->prodname); ?></h5>
                      <div class="d-flex justify-content-between">
                        <p class="card-text"><?php echo e($product->prodprice); ?>$</p>


                      </div>



                    </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learingNow\resources\views/order/customerOrders.blade.php ENDPATH**/ ?>